export class Personas{
  id ?:number;
  nombre:string;
  apellido:string;
}
